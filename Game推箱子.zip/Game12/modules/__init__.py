'''初始化'''
from .sprites import pusherSprite, elementSprite
from .interfaces import startInterface, endInterface, switchInterface