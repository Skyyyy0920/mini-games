'''初始化'''
from .game import gemSprite, gemGame