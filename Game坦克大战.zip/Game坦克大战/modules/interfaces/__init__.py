'''初始化'''
from .gameEndIterface import gameEndIterface
from .gameStartInterface import gameStartInterface
from .switchLevelIterface import switchLevelIterface